
AKSESSHILED-LOGIN


cd login
$ nano Moreno77.txt
Copy Teks Python Log.py
$ ctrl + x + (y) + 
$ nano .bashrc
pastekan di dalam .bashrc
$ ctrl + x
$ nano log.py
cari tempat setting username+password
         if x=="Username" and e=="Password":
username di ganti nick lu dan password diganti Password sesuai keinginan
$mv log.py /$HOME

SELESAI SELAMAT MENCONA